﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItemEntryBlazor.Domain.Enums
{
    public enum Colour
    {
        RED = 1, GREEN, BLUE, YELLOW, MAGENTA
    }
}
