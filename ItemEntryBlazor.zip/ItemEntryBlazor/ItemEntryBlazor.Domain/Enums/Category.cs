﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItemEntryBlazor.Domain.Enums
{
    public enum Category
    {
        Acc = 1, ACCESSORIES_CHEMICAL, AIR_CONDITIONER, SOUNDS_SYSTEM, SHELL, PADDING, LINING, INTERLINING, VACUM_STEAM
    }

}
