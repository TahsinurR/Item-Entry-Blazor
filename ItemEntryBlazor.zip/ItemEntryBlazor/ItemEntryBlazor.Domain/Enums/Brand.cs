﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItemEntryBlazor.Domain.Enums
{
    public enum Brand
    {
        Fashion_Frenzy = 1, Threads_Treasures, Catwalk_Couture, Dresscraft_Designs, Fabrics_Feathers, Fashion_Flair, Dresscode_Depot, Fashion_Oasis, BUTTR
    }

}
