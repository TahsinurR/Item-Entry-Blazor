﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItemEntryBlazor.Domain.Enums
{
    public enum Unit
    {
        PIECE = 1, METER, CENTEMETER, YDS
    }
}
