﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItemEntryBlazor.Domain.Enums
{
    public enum ExpCategory
    {
        BANK_CHG_GENERAL = 1, ACCRUAL_CONTRIBUTION_PF, ADVANCE_WAGES, ADVERTISING_RECRUITMENT,
    }

}
