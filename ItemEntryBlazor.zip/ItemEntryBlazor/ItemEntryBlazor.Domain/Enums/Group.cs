﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItemEntryBlazor.Domain.Enums
{
    public enum Group
    {
        RAW_MATERIAL = 1, CONCURRENT_ITEMS, CAPITAL_ITEMS
    }

}
