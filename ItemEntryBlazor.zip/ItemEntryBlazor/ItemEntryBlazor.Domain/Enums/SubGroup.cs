﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItemEntryBlazor.Domain.Enums
{
    public enum SubGroup
    {
        FABRIC_BODY = 1, FABRIC_TRIM, FINANCE_COST, INEFFICIENCY, OTHER_DIRECT_COST, ACCESSORIES, EQUIPMENT, PACKING_ACCESSORIES

    }

}
