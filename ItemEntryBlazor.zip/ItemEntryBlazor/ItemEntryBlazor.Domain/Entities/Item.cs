﻿using ItemEntryBlazor.Domain.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Group = ItemEntryBlazor.Domain.Enums.Group;

namespace ItemEntryBlazor.Domain.Entities
{
    public class Item
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Please Provide Item Name")]
        [StringLength(100)]
        public string? Item_Name { get; set; }
        [Required(ErrorMessage = "Please Provide Item PCode")]
        [StringLength(100)]
        public string? Item_PCode { get; set; }

        public string? Item_Size_Width { get; set; }

        public string? Item_Model_Orgin { get; set; }

        public string? Item_Unit_Price { get; set; }

        public string? Item_Vat { get; set; }

        public string? Item_Article { get; set; }

        public string? Item_ShadeNo { get; set; }

        public string? Item_MinLQ { get; set; }

        public string? Item_MaxLQ { get; set; }

        public string? Item_Remarks { get; set; }
        [EnumDataType(typeof(Group), ErrorMessage = "Please Select a Group")]
        public Group Group { get; set; }
        [EnumDataType(typeof(SubGroup), ErrorMessage = "Please Select a SubGroup")]
        public SubGroup SubGroup { get; set; }
        [EnumDataType(typeof(Category), ErrorMessage = "Please Select a Category")]
        public Category Category { get; set; }
        [EnumDataType(typeof(Unit), ErrorMessage = "Please Select a Unit")]
        public Unit Unit { get; set; }

        public Brand Brand { get; set; }

        public Colour Colour { get; set; }

        public ExpCategory ExpCategory { get; set; }
    }
}
