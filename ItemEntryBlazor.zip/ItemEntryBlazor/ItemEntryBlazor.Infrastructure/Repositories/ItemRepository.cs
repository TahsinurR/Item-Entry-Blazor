﻿using ItemEntryBlazor.Application.Interfaces;
using ItemEntryBlazor.Domain.Entities;
using ItemEntryBlazor.Infrastructure.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItemEntryBlazor.Infrastructure.Repositories
{
    public class ItemRepository : IItemRepository
    {
        private readonly ItemEntryBlazorDbContext context;
        public ItemRepository(IDbContextFactory<ItemEntryBlazorDbContext> factory)
        {
            context = factory.CreateDbContext();
        }

        public async Task AddAsync(Item item)
        {
            context.Items.Add(item);
            await context.SaveChangesAsync();
        }

        public async Task DeleteByIdAsync(int id)
        {
            var item = await GetByIdAsync(id);
            if (item is not null)
            {
                context.Items.Remove(item);
                await context.SaveChangesAsync();
            }
        }

        

        public async Task<List<Item>> GetAllAsync()
        {
            var items = await context.Items.ToListAsync();
            return items;
        }

        public async Task<Item?> GetByIdAsync(int id)
        {
            var item = await context.Items.FirstOrDefaultAsync(e => e.Id == id);
            return item;
        }

        public async Task UpdateAsync(Item item)
        {
            context.Entry(item).State=EntityState.Modified;
            await context.SaveChangesAsync();
        }
    }
}
