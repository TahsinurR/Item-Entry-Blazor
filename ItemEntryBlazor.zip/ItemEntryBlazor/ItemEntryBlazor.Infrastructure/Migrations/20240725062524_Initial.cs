﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ItemEntryBlazor.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Items",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Item_Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Item_PCode = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Item_Size_Width = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Item_Model_Orgin = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Item_Unit_Price = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Item_Vat = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Item_Article = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Item_ShadeNo = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Item_MinLQ = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Item_MaxLQ = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Item_Remarks = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Group = table.Column<int>(type: "int", nullable: false),
                    SubGroup = table.Column<int>(type: "int", nullable: false),
                    Category = table.Column<int>(type: "int", nullable: false),
                    Unit = table.Column<int>(type: "int", nullable: false),
                    Brand = table.Column<int>(type: "int", nullable: false),
                    Colour = table.Column<int>(type: "int", nullable: false),
                    ExpCategory = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Items", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Items");
        }
    }
}
