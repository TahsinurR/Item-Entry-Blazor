﻿using ItemEntryBlazor.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItemEntryBlazor.Application.Interfaces
{
    public interface IItemRepository
    {
        Task AddAsync(Item item);
        Task<List<Item>> GetAllAsync();
        Task<Item?> GetByIdAsync(int id);
        Task UpdateAsync(Item item);
        Task DeleteByIdAsync(int id);
    }
}
